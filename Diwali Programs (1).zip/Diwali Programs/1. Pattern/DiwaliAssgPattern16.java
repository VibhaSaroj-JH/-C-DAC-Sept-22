class DiwaliAssgPattern16
{
	public static void main(String[] args)
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=13;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
		for(int i=1;i<=5;i++)
		{
			for(int j=11;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=i+2;j++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
		
		for(int i=1;i<=5;i++)
		{
			for(int j=9;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=i+4;j++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
		for(int i=1;i<=5;i++)
		{
			for(int j=7;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=i+6;j++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
		for(int i=1;i<=5;i++)
		{
			for(int j=5;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=i+8;j++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}
		for(int i=1;i<=5;i++)
		{
			System.out.println("         * * * * ");
			
		}
	}
}
/*
            *
           * *
          * * *
         * * * *
        * * * * *
          * * *
         * * * *
        * * * * *
       * * * * * *
      * * * * * * *
        * * * * *
       * * * * * *
      * * * * * * *
     * * * * * * * *
    * * * * * * * * *
      * * * * * * *
     * * * * * * * *
    * * * * * * * * *
   * * * * * * * * * *
  * * * * * * * * * * *
    * * * * * * * * *
   * * * * * * * * * *
  * * * * * * * * * * *
 * * * * * * * * * * * *
* * * * * * * * * * * * *
         * * * *
         * * * *
         * * * *
         * * * *
         * * * *
*/