public class Q24Test
{
	static int x = 17;
	public static void main(String[] args)
	{
		System. out. println(x); //static variable can be called directly.
		System. out. println(Q24Test. x); //static variable can be called with class its name.
	}
}
