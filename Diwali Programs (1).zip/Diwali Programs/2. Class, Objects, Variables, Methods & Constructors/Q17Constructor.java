public class Q17Constructor
{
    double width;
    double height;
    double depth;
    Q17Constructor() 
    {
	System.out.println("Constructor without parameter");
	width = 10;
	height = 10;
	depth = 10;
    }
    Q17Constructor(int a, int b, int c) 
    {
	System.out.println("Constructor with parameter");
	width = a;
	height = b;
	depth = c;
    }
    double volume() 
    {
	return width * height * depth;
    }

    public static void main(String args[]) 
    {
	Q17Constructor cuboid1 = new Q17Constructor();
        double vol;
	vol = cuboid1.volume();
	System.out.println("Volume is " + vol);
	Q17Constructor cuboid2 = new Q17Constructor(8,11,9);
	vol = cuboid2.volume();
	System.out.println("Volume is " + vol);
    }
}
