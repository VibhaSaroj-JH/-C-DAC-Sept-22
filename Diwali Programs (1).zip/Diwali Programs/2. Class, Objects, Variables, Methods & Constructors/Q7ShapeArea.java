
abstract class Area{
	abstract void calArea();
	abstract void getArea();
}
class CircleArea extends Area{
	int r;
	CircleArea(int r){
		this.r = r;
	}
	double area;
	void calArea(){
		area = 3.14*r;
	}
	void getArea(){
		System.out.println("Area of circle is "+area);
	}
}
class SquareArea extends Area{
	int s;
	SquareArea(int s){
		this.s = s;
	}
	double area;
	void calArea(){
		area = s*s;
	}
	void getArea(){
		System.out.println("Area of Square is "+area);
	}
}
class RectangleArea extends Area{
	int s1;
	int s2;
	RectangleArea(int s1, int s2){
		this.s1 = s1;
		this.s2 = s2;
	}
	double area;
	void calArea(){
		area = s1*s2;
	}
	void getArea(){
		System.out.println("Area of Rectangle is "+area);
	}
}

class Q7ShapeArea{
	public static void main(String[] args){
		CircleArea C1 = new CircleArea(3);
		C1.calArea();
		C1.getArea();
		
		SquareArea S1 = new SquareArea(4);
		S1.calArea();
		S1.getArea();
		
		RectangleArea R1 = new RectangleArea(4,6);
		R1.calArea();
		R1.getArea();
	}
}