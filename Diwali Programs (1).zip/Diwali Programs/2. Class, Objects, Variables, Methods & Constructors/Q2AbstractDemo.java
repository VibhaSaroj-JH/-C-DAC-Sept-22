
abstract class Demo{
	int a;
	int b;
	void anotherFun(){
		System.out.println("anotherFun of Demo class calling");
	}

	abstract void abstractFun();
}

abstract class AbstractChild extends Demo{
	int c;
}
class NonAbstractChild extends Demo{
	int d;
	
	void abstractFun(){
		System.out.println("abstractFun of NonAbstractChild class calling");
	}
	
}

public class Q2AbstractDemo{
	public static void main(String[] args){
	
	
	NonAbstractChild C1 = new NonAbstractChild();
	
	C1.anotherFun();
	C1.abstractFun();
	}
}