import java.lang.reflect.Method;
 
public class Q15Test {
    public void getSampleMethod() {}
    public String setSampleMethod()
    {
 
        String str = "hello India";
        return str;
    }
    public static void main(String args[])
    {
 
        try {
            Class c = Test.class;
            Method[] methods = c.getMethods();
            for (Method m : methods) {
                int hashCode = m.hashCode();
                System.out.println("hashCode of method "+ m.getName()+ " is " + hashCode);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
