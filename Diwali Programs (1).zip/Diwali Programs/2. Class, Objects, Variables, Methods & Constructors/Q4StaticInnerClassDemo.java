class Batsman 
{
	int run = 1000;
	
	Batsman()
	{
	}

	void printAverage()
	{
		System.out.println("printAverage of Batsman");
		AvgCalculator avgCal = new AvgCalculator();
		avgCal.myFun();
	}

	//Static Inner class
	static class AvgCalculator
	{
		void myFun()
		{
			System.out.println("myFun of AvgCalculator");
		}
	}
}

class Q4StaticInnerClassDemo
{
	public static void main(String args[])
	{
		Batsman bats1 = new Batsman();
		bats1.printAverage();	

		Batsman.AvgCalculator avgCal = new Batsman.AvgCalculator();
		avgCal.myFun();

	}
}
