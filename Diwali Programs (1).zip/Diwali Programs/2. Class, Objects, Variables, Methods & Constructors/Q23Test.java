public class Q23Test
{
    int x = 17;
    public static void main(String...a)
    {
        Q23Test ob = new Q23Test();// without static it cant be accessed in main method
        System.out.println(ob.x);
    }
}
