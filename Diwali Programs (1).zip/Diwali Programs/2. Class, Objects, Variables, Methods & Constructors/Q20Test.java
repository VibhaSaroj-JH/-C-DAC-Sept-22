import java.util.*;
public class Q20Test
{
	public static void main(String args[])
    {
		String s = new String();
		s= "java";
		System.out.println(s);
		String s2 = new String("Hello Java");
		System.out.println(s2);
		char chars[ ] = { 's', 'c', 'i', 'e', 'n', 'c', 'e' }; 
		String s3 = new String(chars); 
        System.out.println(s3);
		String s4 = new String(chars, 0,4); 
		System.out.println(s4); 
		String s5 = new String(s4); 
		System.out.println(s5); 
		byte b[] = { 97, 98, 99, 100 };
		String s6 = new String(b); 
		System.out.println(s6); 
        String s7 = new String(b, 0, 2);  
        System.out.println(s7); 		
	}
}
