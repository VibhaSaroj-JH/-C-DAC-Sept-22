public class Q8ObjectsCount
{
    static int count=0;
    Q8ObjectsCount()
    {
        count++;
    }
	static void objCount(){
		System.out.println("Number of objects are:"+count);
	}
    public static void main(String[] args) 
    {
        Q8ObjectsCount obj1 = new Q8ObjectsCount();
        Q8ObjectsCount obj2 = new Q8ObjectsCount();
        Q8ObjectsCount obj3 = new Q8ObjectsCount();
        Q8ObjectsCount obj4 = new Q8ObjectsCount();
        Q8ObjectsCount obj5 = new Q8ObjectsCount();
        Q8ObjectsCount obj6 = new Q8ObjectsCount();
        Q8ObjectsCount obj7 = new Q8ObjectsCount();
        Q8ObjectsCount obj8 = new Q8ObjectsCount();
        Q8ObjectsCount.objCount();
		
    }
}