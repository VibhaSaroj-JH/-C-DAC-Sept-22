public class Q5RefInnerClassDemo
{
    static Q4RefInnerClassDemo.InnerClass obj;
    void test1()
    {
        System.out.println("Success");
    }
    static public class InnerClass
    {
    	private String name = "Peakit";
        public void test2()
        {
            Q4RefInnerClassDemo outer = new Q4RefInnerClassDemo();
            outer.test1();
        }
    }
    public static void main(String[] args)
    {
        obj = new Q4RefInnerClassDemo.InnerClass();
        obj.test2();
    }
}
