//Write a program to print elements of Array ?

import java.util.Scanner;

class Array1
{
	static void printArray(int a1[])
	{
		int n= a1.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(a1[j]+" ");
		}
	}
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array you want to print.");
		int length= sc.nextInt();
		int arr []= new int[length];
		System.out.println("Enter the elements of the array: ");
		
		for(int i=0;i<length;i++)
		{
			arr[i]= sc.nextInt();
		}
		System.out.println("Printing elements of the array: ");
		printArray(arr);
		
	}
}