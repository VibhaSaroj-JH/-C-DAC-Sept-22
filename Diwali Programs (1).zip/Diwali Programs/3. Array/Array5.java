/* Find out smallest and largest number in a given Array?*/

import java.util.Scanner;

class Array5
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	static void compare(int arr[])
	{
		int l= arr.length;
		int small=arr[0], large=arr[0];
		for(int i=0;i<l;i++)
		{
			if(arr[i]<small)
			{
				small= arr[i];
			}
			else if(arr[i]>large)
			{
				large= arr[i];
			}	
		}
		System.out.println("\nSmallest number in array is: "+small);
		System.out.println("Largest number in array is: "+large);
	}
	
	 
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of array: ");
		
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
	
		System.out.println("Printing elements of array : ");
		printArray(arr1);
		compare(arr1);
		
	}
}