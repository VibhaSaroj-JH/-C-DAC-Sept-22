/* Write a program which takes an array of integers and prints the running average of 3 
consecutive integers. 
In case the array has fewer than 3 integers, there should be no output.
Input: [5,14,35,89,140]
Output: [18, 46, 88] 
(Explanation: 18=(5+14+35/3, 46=(14+35+89)/3, ...)
*/

import java.util.Scanner;

class Array8
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	static void consecutive(int arr[], int arrC[])
	{
		int m=arr.length;
	if (m<3)
		{
			System.out.println(" ");
		}
		
		for(int i= 0; i<m-2; i++)
		{
			arrC[i] = (arr[i]+arr[i+1]+arr[i+2])/3;
		}
		
	}
    
     
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of array : ");
		
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
	
		int arr2 []= new int[length1-2];
		
		
	
		System.out.println("\nPrinting elements of array 1 : ");
		printArray(arr1);
		System.out.println("\nPrinting elements of consecutive array : ");
		consecutive(arr1,arr2);
		printArray(arr2);
		
	}
}