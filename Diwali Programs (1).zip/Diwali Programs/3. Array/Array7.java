/* Write a program to merge two arrays of integers by reading one number at a time from 
each array until one of the array is exhausted, and then concatenating the remaining 
numbers.
Input: [23,60,94,3,102] and [42,16,74]
Output: [23,42,60,16,94,74,3,102]
*/

import java.util.Scanner;

class Array7
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
    static void alternateMerge(int arr1[], int arr2[], int arr3[])
    {
		int l1=arr1.length;
		int l2=arr2.length;
        int i = 0, j = 0, k = 0;
     
        while (i < l1 && j < l2)
        {
            arr3[k++] = arr1[i++];
            arr3[k++] = arr2[j++];
        }
		 // remaining elements of second array
        while (i < l1)
            arr3[k++] = arr1[i++];
     
        //remaining elements of second array
        while (j < l2)
            arr3[k++] = arr2[j++];
    }
     
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array 1 you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of array 1: ");
		//[23,60,94,3,102]
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
		
		System.out.println("Dear user, give length of array 2 you want to print.");
		int length2= sc.nextInt();
		int arr2 []= new int[length2];
		System.out.println("Enter the elements of array 2: ");
		//[42,16,74]
		for(int i=0;i<length2;i++)
		{
			arr2[i]= sc.nextInt();
		}
	
		int arr3[] = new int[length1+length2];
		System.out.println("\nPrinting elements of array 1 : ");
		printArray(arr1);
		System.out.println("\nPrinting elements of array 2 : ");
		printArray(arr2);
		
		alternateMerge(arr1,arr2,arr3);
		System.out.println("\nPrinting elements of array 3 : ");
		printArray(arr3);
	}
}