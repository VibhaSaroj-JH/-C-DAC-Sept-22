/*Write a Java program to find all pairs of elements in an integer array whose sum is equal 
to a given number?*/

import java.util.Scanner;

class Array3
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	public static void getPairs(int arr[], int sum)
    {
 
        int count = 0;
 
        
        for (int i = 0; i < arr.length; i++)
			
            for (int j = i + 1; j < arr.length; j++)
				
                if ((arr[i] + arr[j]) == sum)
				{
					System.out.printf("("+arr[i]+"+"+arr[j]+")");
                    count++;
				}
        System.out.printf("\nCount of pairs is %d", count);
    }
	
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of array: ");
		
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
	
		System.out.println("Printing elements of array : ");
		printArray(arr1);
		System.out.println("\nProvide sum you want pair of : ");
		int sum= sc.nextInt();
		System.out.println("The sum is: "+sum);
		System.out.println("Pairs are: ");
		getPairs(arr1, sum);
		
		
	}
}