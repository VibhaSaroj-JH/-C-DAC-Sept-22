//Write a Java program to check the equality of two arrays?

import java.util.Scanner;

class Array2
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	static void equalArray(int arr1[], int arr2[])
	{
		if (arr1.length==arr2.length)
		{
			for(int i=0; i< arr1.length; i++)
			{
				if (arr1[i] != arr2[i])
				{
					System.out.println("\nArrays are not equal..");
					break;
				}
			}
			System.out.println("\nArrays are equal..");
		}
		else
		{
			System.out.println("\nArrays are not equal.");
		}
	}
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of 1st array you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of 1st array: ");
		
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
		
		System.out.println("\nDear user, give length of 2nd array you want to print.");
		int length2= sc.nextInt();
		int arr2 []= new int[length2];
		System.out.println("Enter the elements of 2nd array: ");
		
		for(int i=0;i<length2;i++)
		{
			arr2[i]= sc.nextInt();
		}
		System.out.println("Printing elements of 1st array : ");
		printArray(arr1);
		
		System.out.println("Printing elements of 2nd array : ");
		printArray(arr2);
		
		equalArray(arr1,arr2);
		
	}
}