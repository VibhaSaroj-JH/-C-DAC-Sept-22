/* Print the third-largest number in an array without sorting it 
Input: [ 24,54,31,16,82,45,67]
Output: 54 (82 and 67 are the largest and second-largest)*/

import java.util.Scanner;

class Array6
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	static void thirdLargest(int arr[]) {
        int l= arr.length;
        if (l<3) 
		{
            System.out.printf(" Invalid Input ");
            return;
        }
 
        int first = arr[0], second = Integer.MIN_VALUE,
                            third = Integer.MIN_VALUE;
 
        
        for (int i=1; i<l; i++) 
		{
            if (arr[i] > first) 
			{
                third = second;
                second = first;
                first = arr[i];
            } 
            else if (arr[i] > second) 
			{
                third = second;
                second = arr[i];
            } 
            else if (arr[i] > third) 
			{
                third = arr[i];
            }
        }
 
        System.out.printf("\nThe third Largest element is %d\n", third);
    }
 
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of array: ");
		//[ 24,54,31,16,82,45,67]
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
	
		System.out.println("Printing elements of array : ");
		printArray(arr1);
		thirdLargest(arr1);
		
	}
}