/* How to convert a byte array to String?*/

import java.util.Scanner;

class Array11
{
	static void printArray(byte arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of series you want to print.");
		int length1= sc.nextInt();
		byte arr1 []= new byte[length1];
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextByte();
		}
		
		System.out.println("\nPrinting elements of series : ");
		printArray(arr1);
		System.out.println("\nPrinting elements series convered to string : ");
		String str=new String(arr1);
		System.out.println(str);
		
		
	}
}