/* Given an array of integers, print whether the
 numbers are in ascending order or in 
descending order or in random order without sorting*/

import java.util.Scanner;

class Array10
{
	public static void main(String[] args)
{
	Scanner scanner = new Scanner(System.in);
    int[] a = new int[3];
    a[0] = scanner.nextInt();
    a[1] = scanner.nextInt();
    a[2] = scanner.nextInt();
    
    if (a[0] >= a[1] && a[1] >= a[2]) 
		{
			System.out.println("descending order");
		} 
	else if (a[0] <= a[1] && a[1] <= a[2]) 
		{
			System.out.println("ascending order");
		} 
    else
		{
			System.out.println("not in order");
		}
  }

}