/* Write a program which generates the series rite 
a program which generates the series 1,4,27,16,125,36
^3 ^2 ^3*/

import java.util.Scanner;

class Array9
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	static void series(int arr[])
	{
		int m=arr.length;
		
		for(int i= 0; i<m; i++)
		{
			if(i%2==0)
			{
				arr[i]= ((i+1)*(i+1)*(i+1));
			
			}
			else 
			{
				arr[i]= ((i+1)*(i+1));
				
			}
		}
		
	}
    
     
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of series you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		
		System.out.println("\nPrinting elements of series : ");
		series(arr1);
		printArray(arr1);
		
		
	}
}