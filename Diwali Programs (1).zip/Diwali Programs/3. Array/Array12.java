/*How to rotate an array left and right by a given number K?*/

import java.util.Scanner;

class Array12
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	static void rightRotateByOne(int arr[], int l)
	{
    int i;
    int last = arr[l - 1];
		for (i = l - 2; i >= 0; i--)
		{
			arr[i + 1] = arr[i];
		}
    
		arr[0] = last;
	}

	static void leftRotatebyOne(int arr[], int l)
	{
    
    int first = arr[0], i;
		for (i = 0; i < l - 1; i++)
		{
			arr[i] = arr[i + 1];
		}
		arr[i] = first;
	}

	static void leftRotate(int arr[], int k, int l)
	{
		int i;
		for (i = 0; i < k; i++)
		{
			leftRotatebyOne(arr, l);
		}
	}

	static void rightRotate(int arr[], int k, int l)
	{
		int i;
		for (i = 0; i < k; i++)
		{
			rightRotateByOne(arr, l);
		}
	}
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of series you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
		System.out.println("\nProvide k element ");
		int k= sc.nextInt();
		System.out.println("\nk element is: "+k);
		System.out.println("\nPrinting elements of series : ");
		printArray(arr1);
		
		/*System.out.println("\nRotating elements of series left: ");
		leftRotate(arr1, k, length1);
		printArray(arr1);*/
		
		System.out.println("\nRotating elements of series right: ");
		rightRotate( arr1, k, length1);
		printArray(arr1);
		
		
		
	}
}