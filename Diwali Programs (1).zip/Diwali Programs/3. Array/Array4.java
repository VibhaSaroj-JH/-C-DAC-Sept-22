/* Write a program to reverse an Array in java .*/

import java.util.Scanner;

class Array4
{
	static void printArray(int arr[])
	{
		int n= arr.length;
		for(int j= 0; j<n; j++)
		{
			System.out.print(arr[j]+" ");
		}
	}
	
	 static void reverse(int arr[])
    {
        int i, k, j;
		int n= arr.length;
        for (i = 0; i < n / 2; i++) {
            j = arr[i];
            arr[i] = arr[n-i-1];
            arr[n-i-1] = j;
        }
	}
	
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Dear user, give length of array you want to print.");
		int length1= sc.nextInt();
		int arr1 []= new int[length1];
		System.out.println("Enter the elements of array: ");
		
		for(int i=0;i<length1;i++)
		{
			arr1[i]= sc.nextInt();
		}
	
		System.out.println("Printing elements of array : ");
		printArray(arr1);
		
		System.out.println("\nPrinting elements of array in reverse : ");
		reverse(arr1);
		printArray(arr1);
		
	}
}