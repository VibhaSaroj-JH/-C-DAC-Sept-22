//6. Write a Java program of swap two elements in an array list.

import java.util.*;
public class Collection6
{
	public static void main(String args[])
	{
	    List<String> lStr=new ArrayList<String>();
	    lStr.add("Red");
	    lStr.add("Blue");
	    lStr.add("Orange");
	    lStr.add("Green");
	    lStr.add("Yellow");
		System.out.println(lStr);
	
	      System.out.println("Array list before Swap:");
          for(String a: lStr)
		  {
          System.out.println(a);
		  }
		  Collections.swap(lStr, 0, 2);
          System.out.println("Array list after swap:");
          for(String b: lStr)
		  {
          System.out.println(b);
		  }
	
	}
}