//8. Write a Java program to append the specified element to the end of a linked list.

import java.util.*;
public class Collection8
{
	public static void main(String args[])
	{
	    List<String> lStr=new ArrayList<String>();
	    lStr.add("Red");
	    lStr.add("Blue");
	    lStr.add("Orange");
	    lStr.add("Green");
	    lStr.add("Yellow");
		
		System.out.println(lStr);
	    lStr.add("Violet");
	    System.out.println("List after add Violet" +lStr);
	
	
	
	}
}