//4.Write a java program to sort ArrayList
import java.util.*;
public class Collection4
{
	public static void main(String args[])
	{
	List<String> lStr = new ArrayList<String>();
	lStr.add("Red");
	lStr.add("Blue");
	lStr.add("Orange");
	lStr.add("Green");
	lStr.add("Yellow");
	System.out.println(lStr);
	
	Collections.sort(lStr);
	System.out.println("List after sorting: "+lStr);  
	
	
	}
}