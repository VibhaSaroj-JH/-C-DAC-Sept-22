//2. Write a Java program to insert an element into the array list at the first position.

import java.util.*;
public class Collection2
{
	public static void main(String args[])
	{
	List<String> lStr = new ArrayList<String>();
	lStr.add("Red");
	lStr.add("Blue");
	lStr.add("Orange");
	lStr.add("Green");
	lStr.add("Yellow");
	System.out.println(lStr);
	
	lStr.add(0, "Violet");
	
	System.out.println(lStr);
	}
}