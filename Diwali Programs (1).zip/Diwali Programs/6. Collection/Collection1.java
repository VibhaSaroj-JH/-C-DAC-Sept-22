//1. Write a Java program to create a new array list, add some colors (string) and print out the collection

import java.util.*;
public class Collection1
{
	public static void main(String args[])
	{
	List<String> lStr = new ArrayList<String>();
	lStr.add("Red");
	lStr.add("Blue");
	lStr.add("Orange");
	lStr.add("Green");
	lStr.add("Yellow");
	System.out.println(lStr);
	
	}
}