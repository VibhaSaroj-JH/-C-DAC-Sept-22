// 11
import java.util.*;
public class Collection11
{
	public static void main(String args[])
	{
	LinkedList<String> LL=new LinkedList<String>();
	LL.add("Red");
	LL.add("Blue");
	LL.add("Yellow");
	LL.add("Green");
	LL.add("Violet");
	System.out.println(LL);
	
	System.out.println("Original linked list:" + LL);  
	for(int x=0; x < LL.size(); x++)
	{
      System.out.println("Element at index "+x+": "+LL.get(x));
    }  
	
	}
}