//7.Write a java program to print all the elements of a ArrayList using the position of the elements.
import java.util.*;
public class Collection7
{
	public static void main(String args[])
	{
	    List<String> lStr=new ArrayList<String>();
	    lStr.add("Red");
	    lStr.add("Blue");
	    lStr.add("Orange");
	    lStr.add("Green");
	    lStr.add("Yellow");
		System.out.println(lStr);
	System.out.println("\nOriginal array list: " + lStr);
	System.out.println("\nPrint using index of an element: ");
	int no_of_elements = lStr.size();
	for (int index=0; index<no_of_elements; index++)
	System.out.println(lStr.get(index));
	
	}
}