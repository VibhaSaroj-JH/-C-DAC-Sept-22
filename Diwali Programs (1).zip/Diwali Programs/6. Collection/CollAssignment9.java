//9. Write a Java program to insert the specified element at the specified position in the linked list.

import java.util.*;
public class CollAssignment9
{
	public static void main(String args[])
	{
	    List<String> lStr=new ArrayList<String>();
	    lStr.add("Red");
	    lStr.add("Blue");
	    lStr.add("Orange");
	    lStr.add("Green");
	    lStr.add("Yellow");
		
		System.out.println("List = "+lStr);
	
	System.out.println(" Add the Violet color after the Red Color: " + lStr);
	lStr.add(1, "Violet");
	System.out.println("list="+lStr);


	
	}
}