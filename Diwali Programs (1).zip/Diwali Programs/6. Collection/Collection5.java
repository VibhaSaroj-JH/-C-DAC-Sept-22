//5. Write a Java program to reverse elements in a array list.
import java.util.*;
public class Collection5
{
	public static void main(String args[])
	{
	List<String> lStr=new ArrayList<String>();
	lStr.add("Red");
	lStr.add("Blue");
	lStr.add("Orange");
	lStr.add("Green");
	lStr.add("Yellow");
	
	System.out.println("List before reversing :\n"+lStr);  
	Collections.reverse(lStr);
	System.out.println("List after reversing :\n"+lStr); 
		
	}
}