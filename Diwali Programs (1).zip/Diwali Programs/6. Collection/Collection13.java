//13. Write a Java program to compare two linked lists.

import java.util.*;
public class Collection13
{
	public static void main(String args[])
	{
	    LinkedList<String> LL1 = new LinkedList<String>();
	    LL1.add("Red");
	    LL1.add("Blue");
	    LL1.add("Yellow");
	    LL1.add("Green");
	    LL1.add("Violet");
	
	    LinkedList<String> LL2 = new LinkedList<String>();
	    LL2.add("Red");
	    LL2.add("green");
	    LL2.add("yellow");
	    LL2.add("orange");
	    LL2.add("white");
	
	LinkedList<String> LL3 = new LinkedList<String>();
    for (String x : LL1)
        LL3.add(LL2.contains(x) ? "Yes" : "No");
        System.out.println(LL3);         
     
	
	}
}