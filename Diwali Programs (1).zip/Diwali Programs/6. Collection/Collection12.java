//12. Write a Java program to check if a particular element exists in a linked list.
import java.util.*;
public class Collection12
{
	public static void main(String args[])
	{
	LinkedList<String> LL=new LinkedList<String>();
	LL.add("Red");
	LL.add("Blue");
	LL.add("Yellow");
	LL.add("Green");
	LL.add("Violet");
	System.out.println(LL);
	
	if (LL.contains("Green")) {
       System.out.println("Color Green is present in the linked list1!");
    }
	else 
	{
       System.out.println("Color Green is not present in the linked list!");
    }
    
    if (LL.contains("Orange")) 
	{
       System.out.println("Color Orange is present in the linked list!");
    } 
	else 
	{
       System.out.println("Color Orange is not present in the linked list!");
	}
	
	}
}