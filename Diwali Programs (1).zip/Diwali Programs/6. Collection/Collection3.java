//3. Write a Java program to retrieve an element (at a specified index) from a given array list.

import java.util.*;
public class Collection3
{
	public static void main(String args[])
	{
	List<String> lStr=new ArrayList<String>();
	lStr.add("Red");
	lStr.add("Blue");
	lStr.add("Orange");
	lStr.add("Green");
	lStr.add("Yellow");
	System.out.println(lStr);
	
	lStr.add(0, "Violet");
	lStr.add(5, "Grey");
	
	System.out.println(lStr);
	
	String element = lStr.get(0);
	System.out.println("First element: "+element);
	element = lStr.get(2);
	System.out.println("Third element: "+element);
	
	}
}