//10. Write a Java program to insert elements into the linked list at the first and last position.
import java.util.*;
public class CollAssignment10
{
	public static void main(String args[])
	{
	LinkedList<String> LL = new LinkedList<String>();
	LL.add("Red");
	LL.add("Blue");
	LL.add("Yellow");
	LL.add("Green");
	LL.add("Violet");
	System.out.println(LL);
	
	System.out.println("Original linked list:" +LL);    
   
    LL.addFirst("White");
    LL.addLast("Pink");
	
    System.out.println("Final linked list:" + LL); 
	
	}
}