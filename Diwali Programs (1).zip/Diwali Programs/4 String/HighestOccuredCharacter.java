//19:- How to return the highest occurred character in a String? 
//For example if input is "aaaaaaaaaaaaaaaaabbbbcddddeeeeee" it should return "a".
public class HighestOccuredCharacter 
{
    static final int ASCII_SIZE = 256;
    static char getMaxOccurringChar(String str)
    {
        int count[] = new int[ASCII_SIZE];
        int len = str.length();
        for (int i = 0; i < len; i++)
            count[str.charAt(i)]++;
 
        int max = -1;
        char result = ' ';
        for (int i = 0; i < len; i++) 
		{
            if (max < count[str.charAt(i)]) 
			{
                max = count[str.charAt(i)];
                result = str.charAt(i);
            }
        }
 
        return result;
    }
    public static void main(String[] args)
    {
        String str = "aaaaaaaaaaaaaaaaaaaaaaaabbbbbbccccccccc";
        System.out.println("Max occurring character is "+ getMaxOccurringChar(str));
    }
}