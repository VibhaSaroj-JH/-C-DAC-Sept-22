


//11. How to replace each given character to other e.g. blank with %20? 

import java.util.*;
public class q11 {  
     public static void main(String[] args)
	 {  
          String s1="Java is Great";
          System.out.println(s1.replaceAll(" ","%20")); 
          
		
    }  
}  