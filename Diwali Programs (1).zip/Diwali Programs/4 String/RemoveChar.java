//20:- Write a program to remove a given character from String?
public class RemoveChar 
{
	public static String charRemoveAt(String str, int p) 
	{
	return str.substring(0, p) + str.substring(p + 1);
	}
	public static void main(String[] args) 
	{
	String str = "This World shall know PAIN";
	System.out.println(charRemoveAt(str, 7));
	}
}