

// 12. For example, if the input is "Java is Great" and asked to replace space with %20 then it 
//  should be "Java%20is%20Great".

import java.util.*;
public class q12 {  
     public static void main(String[] args)
	 {  
	    Scanner sc=new Scanner(System.in);
		String string1=sc.nextLine(); 
		
	 
	     // String s1="Java is Great";
          System.out.println(string1.replaceAll(" ","%20")); 
       
    }  
}  