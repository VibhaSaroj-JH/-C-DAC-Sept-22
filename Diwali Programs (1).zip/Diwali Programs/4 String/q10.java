
//10. For example, if you pass "67263" to the program then it should return 67263.

import java.util.*;
public class q10 {  
     public static void main(String[] args)
	 {  
       Scanner sc=new Scanner(System.in);
		String string1=sc.nextLine();  
		
            int number = Integer.parseInt(string1);
            System.out.println(number); // output = 25 
    }  
}  