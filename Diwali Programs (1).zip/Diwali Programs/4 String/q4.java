

// 4. How to program to print the first non repeated character from String?

import java.util.*;
class q4
{
	
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		String x=sc.nextLine();
		
		
		char str1[]=x.toCharArray();
		
		
		for(int i=0;i<str1.length;i++)
		{
			int count=0;
			for(int j=0;j<str1.length;j++)
			{
				if(str1[i]==str1[j])
				{
					count++;		
				}
			}
			if(count<2)
			{
				System.out.println(str1[i]);
				break;
			}
		}
		
	}
}