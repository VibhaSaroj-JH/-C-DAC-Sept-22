

// 2. For example, if String is "Java" then the program should print "a"

import java.util.*;
class q2
{
	
	public static void main(String [] args)
	{
		String x="java";
		Scanner sc =new Scanner(System.in);
		String y=sc.next();
		
		
		if(x.equals(y)==true)
		{
			System.out.println("a");
		}
		
	}
}