

// 9. How to convert numeric String to an int?

import java.util.*;
public class q9 {  
     public static void main(String[] args) {  
       Scanner sc=new Scanner(System.in);
		String string1=sc.nextLine();  
          
        int number = Integer.parseInt(string1);
        System.out.println(number); // output = 25 
          
          
		
    }  
}  