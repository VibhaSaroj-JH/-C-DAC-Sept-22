/*
11. Given two strings, s and t, merge the two strings together alternating characters starting 
with s.
Note: If one string is longer than the other, append the remaining characters of the longer 
string at the end of the merged string.
s = "abc", t = "def", return "adbecf".
*/

import java.util.*;

class SplQuestion11
{
	public static void main(String args[])
	{
		String str1="abc";
		String str2="def";
		int i=0;
		int j=0;
		
		char[] str3= new char[str1.length()+str2.length()]
		
		
	}
}